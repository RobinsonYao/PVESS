# Next Tasks

## Priority 1

EMSModel V0.2

目标：

支持：

* 光伏消纳
* 峰谷套利
* 需量控制

采用：

Multi-objective

Priority-based

Demo 实现。

---

## Priority 2

DoubleCycleModel

统计：

* daily cycle
* equivalent cycle

---

## Priority 3

EconomicModel MVP

建立：

收益

*

循环寿命成本

分析框架。

---

## Priority 4

TOUModel Skeleton

负责：

* 峰谷时段
* 尖峰
* 深谷
* 地区差异
* 季节变化

---

## Priority 5

TariffModel Skeleton

负责：

* 购电电价
* 上网电价
* 峰谷电价
* 容量电费
* 需量电费

---

保持：

渐进式演化。

避免一次设计完成。
