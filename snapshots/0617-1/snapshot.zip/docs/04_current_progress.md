# 当前进展

## 当前版本

V1.2-alpha

---

## 已完成模块

### WeatherModel

状态：

Freeze

功能：

* 气象数据读取
* 日数据提取
* 月统计
* 绘图功能

---

### PVModel

状态：

Freeze

功能：

* GHI → 光伏功率转换

---

### LoadModel

状态：

Freeze

功能：

* 负荷曲线生成

---

### BatteryModel

状态：

Freeze

职责：

执行层

负责：

* 功率限制
* SOC限制
* 充放电效率
* SOC更新
* Grid功率计算

Battery Power：

正：

放电

负：

充电

Grid Power：

正：

购电

负：

上网

BatteryModel 不负责控制策略。

---

### EMSModel V0.1

状态：

Stable

职责：

决策层

功能：

* 自发自用策略

输入：

* pv_power
* load_power

输出：

* target_battery_power

---

### ResultModel

状态：

Freeze

职责：

观察层

功能：

* build()
* export_csv()
* plot_soc()
* plot_power()
* plot_energy_balance()

输出：

* csv
* png

---

## 已完成测试体系

完成：

* Unit Test
* Scenario Test
* Long-term Test
* EMS + Battery 联合测试

建立标准测试数据集：

* normal
* stress
* historical

采用纵向长表：

dataset

datetime

temperature

ghi

load

tou_period

测试结果采用：

csv + png

进行分析。

---

## 当前系统流程

Weather

↓

PV

↓

Load

↓

EMS

↓

Battery

↓

Result

↓

CSV

↓

PNG

---

## 当前主线

EMSModel V0.2

↓

DoubleCycleModel

↓

EconomicModel MVP

↓

TOUModel

↓

TariffModel

↓

SizingModel

---

## 当前开发原则

讨论

↓

实现

↓

Unit Test

↓

System Test

↓

Long-term Test

↓

输出 csv

↓

输出 png

↓

分析

↓

Debug

↓

Freeze

↓

进入下一模块
