.
├── archives
│   ├── PVESS_V0.6_ProjectMemory.zip
│   ├── PVESS_V1.0-alpha_Source.zip
│   ├── PVESS_V1.1-alpha.zip
│   └── PVESS_V1.2-alpha.zip
├── charts
│   └── __init__.py
├── config
│   ├── __init__.py
│   └── settings.py
├── controllers
│   ├── __init__.py
│   └── simulation_controller.py
├── data
├── docs
│   ├── 00_project_overview.md
│   ├── 01_architecture.md
│   ├── 02_requirements.md
│   ├── 03_development_rules.md
│   ├── 04_current_progress.md
│   ├── 05_next_tasks.md
│   ├── 06_decision_log.md
│   ├── 07_developer_profile.md
│   ├── 08_ai_collaboration_rules.md
│   ├── 09_coding_convention.md
│   ├── 10_glossary.md
│   ├── 11_known_issues.md
│   ├── 12_future_ideas.md
│   ├── 13_version_history.md
│   ├── 14_sizing_architecture.md
│   ├── 15_project_tree.md
│   └── history
│       ├── development_log.md
│       ├── learning_notes.md
│       ├── release_note.md
│       └── roadmap.md
├── docs.zip
├── logs
├── main.py
├── models
│   ├── __init__.py
│   ├── battery_model.py
│   ├── ems_model.py
│   ├── load_model.py
│   ├── pv_model.py
│   ├── result_model.py
│   ├── sizing_model.py
│   ├── tariff_model.py
│   ├── tou_model.py
│   └── weather_model.py
├── projects
├── pytest.ini
├── requirements.txt
├── resources
├── snapshots
│   ├── 0614-1
│   │   └── PVESS_V0.6_ProjectMemory.zip
│   ├── 0615-1
│   │   └── PVESS_V1.0-alpha_Source.zip
│   ├── 0615-2
│   │   └── PVESS_V1.1-alpha.zip
│   ├── 0616-1
│   │   ├── PVESS_V1.2-alpha.zip
│   │   └── PVESS_V1.2-alpha_20260616.zip
│   ├── 0616-2
│   │   └── prompt_for_new_chat.md
│   └── 0617-1
├── tests
│   ├── data
│   │   ├── test_dataset.csv
│   │   └── test_dataset_charge.csv
│   ├── test_battery_execute.py
│   ├── test_dataset_result.py
│   ├── test_double_cycle.py
│   ├── test_ems_battery_system.py
│   ├── test_ems_long_term.py
│   ├── test_ems_model.py
│   ├── test_ems_scenarions.py
│   ├── test_result_model.py
│   ├── test_sizing_model.py
│   └── test_weather_period.py
└── ui
    ├── __init__.py
    └── main_window.py

22 directories, 63 files
