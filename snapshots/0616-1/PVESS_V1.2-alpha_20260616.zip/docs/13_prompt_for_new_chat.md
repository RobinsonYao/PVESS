当前项目：

PVESS（Photovoltaic and Energy Storage Simulation System）

上一卷：

《光储仿真系统说明书VII》

已经结束。

当前版本：

V1.2-alpha

请优先阅读 docs 文件夹。

尤其优先阅读：

00_project_overview.md

01_architecture.md

04_current_progress.md

05_next_tasks.md

06_decision_log.md

07_developer_profile.md

08_ai_collaboration_rules.md

09_coding_convention.md

10_glossary.md

13_prompt_for_new_chat.md

14_version_history.md

15_sizing_architecture.md

当前已经完成：

WeatherModel

PVModel

LoadModel

BatteryModel

EMSModel MVP

完成测试体系：

Unit Test

Scenario Test

Long-term Test

EMS + Battery 联合测试

建立标准测试数据集：

normal

stress

historical

采用纵向长表：

dataset

datetime

temperature

ghi

load

tou_period

形成：

csv + png

分析模式。

开发流程：

讨论

↓

实现

↓

Unit Test

↓

System Test

↓

Long-term Test

↓

输出 csv

↓

输出 png

↓

分析

↓

Debug

↓

Freeze

↓

进入下一模块

当前主线：

ResultModel

↓

Double Cycle Mechanism

↓

Storage Sizing MVP

↓

EconomicModel

保持：

渐进式演化。

不要重构整个系统。

优先：

正确性；

简单性；

工程实用性。

避免：

复杂设计模式；

过度抽象；

一次修改大量文件。

AI职责：

帮助理解；

帮助分析；

帮助调试；

帮助优化；

而不是代替开发。
